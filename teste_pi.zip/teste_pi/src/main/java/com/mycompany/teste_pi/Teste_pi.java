/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teste_pi;

/**
 *
 * @author 25.01627-0
 */
public class Teste_pi {

    public static void main(String[] args) {
        
    }
}
